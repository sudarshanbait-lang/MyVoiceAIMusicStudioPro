package com.myvoice.music

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.os.Environment
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
 private lateinit var server: EditText
 private lateinit var lyrics: EditText
 private lateinit var prompt: EditText
 private lateinit var status: TextView
 private var recorder: MediaRecorder? = null
 private var recording = false
 private var sample: File? = null
 private var player: MediaPlayer? = null
 private val client = OkHttpClient.Builder().connectTimeout(30,TimeUnit.SECONDS).readTimeout(20,TimeUnit.MINUTES).build()
 private fun label(s:String)=TextView(this).apply { text=s; textSize=17f; setTextColor(Color.BLACK); setPadding(0,12,0,5) }
 private fun edit(hint:String,lines:Int=1)=EditText(this).apply { this.hint=hint; minLines=lines; setTextColor(Color.BLACK) }
 private fun button(s:String,action:()->Unit)=Button(this).apply { text=s; setOnClickListener { action() } }
 private fun message(s:String)=runOnUiThread { status.text=s }
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
  val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24) }
  val scroll=ScrollView(this); scroll.addView(layout); setContentView(scroll)
  layout.addView(label("🎵 My Voice AI Music Studio"))
  layout.addView(label("AI Server URL")); server=edit("http://192.168.1.10:8000"); layout.addView(server)
  layout.addView(label("Lyrics (जो आपकी आवाज़ में बोले जाएंगे)")); lyrics=edit("ॐ गं गणपतये नमः",3); layout.addView(lyrics)
  layout.addView(label("Instrumental music prompt (English बेहतर काम करता है)")); prompt=edit("soft Indian devotional instrumental, bansuri, tabla, tanpura, no vocals",3); layout.addView(prompt)
  layout.addView(button("🎙️ Record voice sample (15–30 seconds)") { if(recording) stopRecord() else startRecord() })
  layout.addView(button("📁 Choose voice WAV file") { val i=android.content.Intent(android.content.Intent.ACTION_GET_CONTENT).apply { type="audio/*" }; startActivityForResult(i,100) })
  layout.addView(button("✨ Generate audio") { generate() })
  status=label("Ready. Use only your own voice or a voice you have permission to clone."); layout.addView(status)
 }
 private fun startRecord() {
  if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10); return }
  try { sample=File(cacheDir,"voice.m4a"); recorder=MediaRecorder().apply { setAudioSource(MediaRecorder.AudioSource.MIC); setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioSamplingRate(44100); setOutputFile(sample!!.absolutePath); prepare(); start() }; recording=true; message("Recording... Tap Record again to stop") } catch(e:Exception){message("Recording error: ${e.message}")}
 }
 private fun stopRecord() { try { recorder?.stop(); recorder?.release(); recorder=null; recording=false; message("Voice recorded") } catch(e:Exception){message("Recording error: ${e.message}")} }
 @Deprecated("Deprecated in Android") override fun onActivityResult(requestCode:Int,resultCode:Int,data:android.content.Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==100 && resultCode==RESULT_OK) { try { val f=File(cacheDir,"selected_voice.audio"); contentResolver.openInputStream(data!!.data!!)!!.use { input -> f.outputStream().use { input.copyTo(it) } }; sample=f; message("Voice file selected") } catch(e:Exception){message("File error: ${e.message}")} } }
 private fun generate() {
  val file=sample; if(file==null){message("Record or choose your voice first");return}
  val url=server.text.toString().trim().trimEnd('/'); if(!url.startsWith("http")){message("Enter server URL");return}
  val body=MultipartBody.Builder().setType(MultipartBody.FORM)
   .addFormDataPart("lyrics",lyrics.text.toString()).addFormDataPart("music_prompt",prompt.text.toString())
   .addFormDataPart("voice",file.name,file.asRequestBody("application/octet-stream".toMediaType())).build()
  message("Generating... this may take several minutes")
  Thread { try { val request=Request.Builder().url("$url/generate").post(body).build(); client.newCall(request).execute().use { response ->
    if(!response.isSuccessful) { message("Server error ${response.code}: ${response.body?.string()?.take(400)}");return@use }
    val dir=getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir; val output=File(dir,"my_voice_song_${System.currentTimeMillis()}.mp3")
    response.body!!.byteStream().use { input -> output.outputStream().use { input.copyTo(it) } }
    message("Saved: ${output.absolutePath}")
    runOnUiThread { player?.release(); player=MediaPlayer().apply { setDataSource(output.absolutePath); prepare(); start() } }
  } } catch(e:Exception){message("Connection error: ${e.message}")} }.start()
 }
 override fun onDestroy(){ super.onDestroy(); player?.release(); recorder?.release() }
}
