"""AI server: XTTS voice cloning + MusicGen instrumental + FFmpeg mixing."""
import os, subprocess, tempfile
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

app=FastAPI(title="My Voice AI Music Studio")
VOICE_MODEL=None
MUSIC_MODEL=None

@app.get('/health')
def health(): return {'status':'ok'}

def run(args):
    p=subprocess.run(args, capture_output=True, text=True)
    if p.returncode: raise RuntimeError(p.stderr[-1800:])

@app.post('/generate')
async def generate(voice:UploadFile=File(...), lyrics:str=Form(...), music_prompt:str=Form(...)):
    global VOICE_MODEL,MUSIC_MODEL
    if not lyrics.strip() or not music_prompt.strip(): raise HTTPException(400,'Lyrics and music prompt required')
    if len(lyrics)>1000 or len(music_prompt)>500: raise HTTPException(400,'Prompt too long')
    tmp=tempfile.TemporaryDirectory(); root=Path(tmp.name)
    try:
        import torch, soundfile as sf
        from TTS.api import TTS
        from transformers import pipeline
        device='cuda' if torch.cuda.is_available() else 'cpu'
        raw=root/'voice_upload'; raw.write_bytes(await voice.read())
        if raw.stat().st_size>20_000_000: raise HTTPException(413,'Voice file too large')
        wav=root/'voice.wav'; speech=root/'speech.wav'; music=root/'music.wav'; output=root/'result.mp3'
        run(['ffmpeg','-y','-i',str(raw),'-ar','24000','-ac','1',str(wav)])
        if VOICE_MODEL is None:
            VOICE_MODEL=TTS('tts_models/multilingual/multi-dataset/xtts_v2').to(device)
        # XTTS supports Hindi in some community forks, but stock XTTS-v2 does not officially support 'hi'.
        # For a reproducible baseline use English; Hindi requests receive a clear error.
        if any('\u0900'<=c<='\u097f' for c in lyrics):
            raise HTTPException(422,'This baseline XTTS-v2 model does not support Hindi. Use English lyrics or install a Hindi-capable voice-cloning model.')
        VOICE_MODEL.tts_to_file(text=lyrics, speaker_wav=str(wav), language='en', file_path=str(speech))
        if MUSIC_MODEL is None:
            MUSIC_MODEL=pipeline('text-to-audio',model='facebook/musicgen-small',device=0 if device=='cuda' else -1)
        # ~10 seconds at 32 kHz; repeat music under entire spoken passage.
        generated=MUSIC_MODEL(music_prompt,forward_params={'max_new_tokens':500})
        sf.write(str(music),generated['audio'].squeeze(),generated['sampling_rate'])
        run(['ffmpeg','-y','-stream_loop','-1','-i',str(music),'-i',str(speech),'-filter_complex','[0:a]volume=0.22[m];[m][1:a]amix=inputs=2:duration=shortest:dropout_transition=0[out]','-map','[out]','-codec:a','libmp3lame','-q:a','3',str(output)])
        return FileResponse(output,media_type='audio/mpeg',filename='my_voice_song.mp3',background=BackgroundTask(tmp.cleanup))
    except HTTPException:
        tmp.cleanup(); raise
    except Exception as exc:
        tmp.cleanup(); raise HTTPException(500,str(exc)[:500])
